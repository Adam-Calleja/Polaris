"""Bundled prompt templates for polaris_rag."""
__all__ = []
