"""CLI entrypoints for polaris_rag."""
